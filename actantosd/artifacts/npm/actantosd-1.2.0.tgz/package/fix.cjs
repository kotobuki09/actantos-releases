const fs = require('fs');

let content = fs.readFileSync('src/intercept-service.ts', 'utf8');
content = content.replace(/cedarResult: "forbid"/g, 'cedarResult: { decision: "forbid" }');
content = content.replace(/cedarResult: "permit"/g, 'cedarResult: { decision: "permit" }');
fs.writeFileSync('src/intercept-service.ts', content);

let content2 = fs.readFileSync('src/intercept-fail-closed.ts', 'utf8');
content2 = content2.replace(/cedarResult: options\.cedarResult \?\? "forbid"/g, 'cedarResult: options.cedarResult ?? { decision: "forbid" }');
fs.writeFileSync('src/intercept-fail-closed.ts', content2);

let content3 = fs.readFileSync('src/cedar-cli-provider.ts', 'utf8');
content3 = content3.replace(
  /return \{ decision: output\.decision === "ALLOW" \? "permit" : "forbid", reasonCode: output\.reasonCode \}/g,
  'const result: CedarDecision = { decision: output.decision === "ALLOW" ? "permit" : "forbid" };\n      if (output.reasonCode !== undefined) result.reasonCode = output.reasonCode;\n      return result;'
);
fs.writeFileSync('src/cedar-cli-provider.ts', content3);
